PARCHE 1.1c - ESTADO REAL DEL CONTENIDO

Corrige el falso positivo de los textos.

Ahora un texto se considera completo solamente cuando:
- No contiene las frases típicas de la plantilla.
- No está compuesto únicamente por títulos y datos de Ciudad/Provincia/País.
- Tiene una cantidad mínima de contenido narrativo real.
- Tiene suficientes palabras y caracteres alfabéticos.

Instalación:
1. Extraer el ZIP sobre la carpeta Editor_UBIGUIA.
2. Reemplazar el archivo existente.
3. Ejecutar: python src\main.py
