from pathlib import Path
import json
import re

PLACEHOLDER_WORDS = [
    "escriba", "escribe", "complete", "completa", "indicaciones",
    "si aplica", "texto", "consejos", "créditos", "creditos",
    "referencias", "resumen corto", "historia / contexto",
    "cómo llegar", "como llegar", "horarios", "entradas / precios",
    "tips", "fuentes"
]

def _clean_markdown(content: str) -> str:
    lines = []
    for raw in content.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        line = re.sub(r"[*_`>-]", " ", line)
        line = re.sub(r"\([^)]*\)", " ", line)
        line = re.sub(r"\s+", " ", line).strip()
        if line:
            lines.append(line)
    return " ".join(lines)

def has_real_text(path: Path, min_chars: int = 100) -> bool:
    if not path.exists() or not path.is_file():
        return False
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return False

    cleaned = _clean_markdown(content).lower()
    for word in PLACEHOLDER_WORDS:
        cleaned = cleaned.replace(word, " ")

    cleaned = re.sub(r"[^a-záéíóúüñ0-9\s]", " ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return len(cleaned) >= min_chars

def has_valid_json(path: Path) -> bool:
    if not path.exists() or not path.is_file():
        return False
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return False
    return isinstance(data, dict) and bool(data)

def count_media(folder: Path, extensions: set[str]) -> int:
    if not folder.exists():
        return 0
    return sum(
        1 for p in folder.rglob("*")
        if p.is_file() and p.suffix.lower() in extensions
    )
