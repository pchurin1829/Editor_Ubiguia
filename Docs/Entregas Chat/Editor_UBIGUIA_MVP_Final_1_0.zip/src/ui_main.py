from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox,simpledialog
from tkinter.scrolledtext import ScrolledText
from config import load_config,save_config,project_root
from filesystem import list_dirs,open_folder
from poi_manager import list_pois,next_poi_number,create_poi,city_path,find_master_file
from validator import validate_text
from repair import repair_city
from zip_export import export_pois
from constants import *
def title(n): return n.split("-",1)[1].strip() if "-" in n else n
class EditorUBIGUIA(tk.Tk):
 def __init__(self):
  super().__init__(); self.cfg=load_config(); self.title(f"{APP_NAME} {APP_VERSION}"); self.geometry(f"{self.cfg.get('window_width',1180)}x{self.cfg.get('window_height',760)}")
  self.country_var=tk.StringVar(value=self.cfg.get("last_country","ARGENTINA")); self.province_var=tk.StringVar(value=self.cfg.get("last_province","BUENOS AIRES")); self.city_var=tk.StringVar(value=self.cfg.get("last_city","LA PLATA")); self.build(); self.ensure_root(); self.refresh_all()
 def build(self):
  main=ttk.Frame(self,padding=12); main.pack(fill="both",expand=True)
  box=ttk.LabelFrame(main,text="Proyecto"); box.pack(fill="x"); self.root_label=ttk.Label(box,text="Carpeta TURISMO:"); self.root_label.pack(side="left",padx=8,pady=8); ttk.Button(box,text="Cambiar",command=self.change_root).pack(side="right",padx=8)
  s=ttk.Frame(main); s.pack(fill="x",pady=10)
  ttk.Label(s,text="País").grid(row=0,column=0,sticky="w"); self.country_cb=ttk.Combobox(s,textvariable=self.country_var,width=30,state="readonly"); self.country_cb.grid(row=1,column=0,padx=(0,10)); self.country_cb.bind("<<ComboboxSelected>>",lambda e:self.on_country())
  ttk.Label(s,text="Provincia").grid(row=0,column=1,sticky="w"); self.province_cb=ttk.Combobox(s,textvariable=self.province_var,width=30,state="readonly"); self.province_cb.grid(row=1,column=1,padx=(0,10)); self.province_cb.bind("<<ComboboxSelected>>",lambda e:self.on_province())
  ttk.Label(s,text="Ciudad").grid(row=0,column=2,sticky="w"); self.city_cb=ttk.Combobox(s,textvariable=self.city_var,width=30,state="readonly"); self.city_cb.grid(row=1,column=2); self.city_cb.bind("<<ComboboxSelected>>",lambda e:self.refresh_pois())
  pb=ttk.LabelFrame(main,text="POIs"); pb.pack(fill="both",expand=True); self.poi_list=tk.Listbox(pb,selectmode=tk.EXTENDED); self.poi_list.pack(side="left",fill="both",expand=True,padx=8,pady=8); self.poi_list.bind("<Double-Button-1>",lambda e:self.edit_master()); sc=ttk.Scrollbar(pb,orient="vertical",command=self.poi_list.yview); sc.pack(side="right",fill="y"); self.poi_list.configure(yscrollcommand=sc.set)
  b1=ttk.Frame(main); b1.pack(fill="x",pady=(10,4))
  for text,cmd in [("Nuevo POI",self.new_poi),("Editar MASTER",self.edit_master),("Texto ES",lambda:self.edit_text("ESPAÑOL")),("Texto EN",lambda:self.edit_text("INGLES")),("Texto PT",lambda:self.edit_text("PORTUGUES")),("Imágenes",self.open_images),("Audio ES",lambda:self.open_audio("ESPAÑOL")),("Audio EN",lambda:self.open_audio("INGLES")),("Audio PT",lambda:self.open_audio("PORTUGUES"))]: ttk.Button(b1,text=text,command=cmd).pack(side="left",padx=3)
  b2=ttk.Frame(main); b2.pack(fill="x",pady=(4,0))
  for text,cmd in [("Abrir carpeta",self.open_selected_folder),("Validar POI",self.validate_selected),("Reparar ciudad",self.repair_current_city),("Generar ZIP",self.export_selected),("Actualizar",self.refresh_all)]: ttk.Button(b2,text=text,command=cmd).pack(side="left",padx=3)
  ttk.Button(b2,text="Salir",command=self.destroy).pack(side="right",padx=3)
 def turismo_root(self): return self.cfg.get("turismo_root","")
 def ensure_root(self):
  if not self.turismo_root() or not Path(self.turismo_root()).exists(): messagebox.showinfo("Configuración","Seleccione la carpeta TURISMO."); self.change_root()
 def change_root(self):
  x=filedialog.askdirectory(title="Seleccione la carpeta TURISMO")
  if x:self.cfg["turismo_root"]=x;save_config(self.cfg);self.refresh_all()
 def refresh_all(self):
  r=self.turismo_root(); self.root_label.config(text=f"Carpeta TURISMO: {r}"); c=list_dirs(Path(r)) if r else []; self.country_cb["values"]=c
  if c and self.country_var.get() not in c:self.country_var.set(c[0])
  self.refresh_provinces();self.refresh_pois()
 def refresh_provinces(self):
  p=list_dirs(Path(self.turismo_root())/self.country_var.get());self.province_cb["values"]=p
  if p and self.province_var.get() not in p:self.province_var.set(p[0])
  self.refresh_cities()
 def refresh_cities(self):
  c=list_dirs(Path(self.turismo_root())/self.country_var.get()/self.province_var.get());self.city_cb["values"]=c
  if c and self.city_var.get() not in c:self.city_var.set(c[0])
 def refresh_pois(self):
  self.poi_list.delete(0,tk.END)
  for n in list_pois(self.turismo_root(),self.country_var.get(),self.province_var.get(),self.city_var.get()):self.poi_list.insert(tk.END,n)
  self.cfg.update(last_country=self.country_var.get(),last_province=self.province_var.get(),last_city=self.city_var.get());save_config(self.cfg)
 def on_country(self):self.refresh_provinces();self.refresh_pois()
 def on_province(self):self.refresh_cities();self.refresh_pois()
 def current_city_path(self):return city_path(self.turismo_root(),self.country_var.get(),self.province_var.get(),self.city_var.get())
 def selected_names(self):return [self.poi_list.get(i) for i in self.poi_list.curselection()]
 def selected_path(self):
  n=self.selected_names()
  if not n:messagebox.showwarning("Atención","Seleccione un POI.");return None
  return self.current_city_path()/n[0]
 def selected_paths(self):return [self.current_city_path()/n for n in self.selected_names()]
 def new_poi(self):
  num=next_poi_number(list_pois(self.turismo_root(),self.country_var.get(),self.province_var.get(),self.city_var.get()));name=simpledialog.askstring("Nuevo POI",f"Número sugerido: {num}\n\nNombre:")
  if not name:return
  cat=simpledialog.askstring("Nuevo POI","Categoría (opcional):") or ""
  try:create_poi(self.turismo_root(),self.country_var.get(),self.province_var.get(),self.city_var.get(),num,name,cat);self.refresh_pois();messagebox.showinfo("Listo","POI creado correctamente.")
  except Exception as e:messagebox.showerror("Error",str(e))
 def edit_file(self,p,t):
  p.parent.mkdir(parents=True,exist_ok=True)
  if not p.exists():p.write_text("",encoding="utf-8")
  w=tk.Toplevel(self);w.title(t);w.geometry("900x650");txt=ScrolledText(w,wrap="word",font=("Arial",11));txt.pack(fill="both",expand=True,padx=10,pady=10);txt.insert("1.0",p.read_text(encoding="utf-8",errors="replace"))
  def save():p.write_text(txt.get("1.0","end-1c"),encoding="utf-8");messagebox.showinfo("Guardado","Archivo guardado correctamente.");w.destroy()
  bar=ttk.Frame(w);bar.pack(fill="x",padx=10,pady=8);ttk.Button(bar,text="Guardar",command=save).pack(side="right",padx=4);ttk.Button(bar,text="Cancelar",command=w.destroy).pack(side="right",padx=4)
 def edit_master(self):
  p=self.selected_path()
  if p:
   m=find_master_file(p) or p/POI_MASTER_FILE
   if not m.exists():m.write_text(f"# POI MASTER\n\n# {title(p.name)}\n",encoding="utf-8")
   self.edit_file(m,f"MASTER - {p.name}")
 def edit_text(self,lang):
  p=self.selected_path()
  if p:self.edit_file(p/lang/TEXT_FILE,f"Texto {lang} - {p.name}")
 def open_images(self):
  p=self.selected_path()
  if p:(p/SHARED_IMAGES_FOLDER).mkdir(parents=True,exist_ok=True);open_folder(p/SHARED_IMAGES_FOLDER)
 def open_audio(self,lang):
  p=self.selected_path()
  if p:(p/lang/AUDIO_FOLDER).mkdir(parents=True,exist_ok=True);open_folder(p/lang/AUDIO_FOLDER)
 def open_selected_folder(self):
  p=self.selected_path()
  if p:open_folder(p)
 def validate_selected(self):
  p=self.selected_path()
  if p:messagebox.showinfo("Validación",validate_text(p))
 def repair_current_city(self):
  c=self.current_city_path()
  if messagebox.askyesno("Confirmar",f"Reparar estructura de:\n{c}?"):messagebox.showinfo("Reparación","\n".join(repair_city(c)[:80]));self.refresh_all()
 def export_selected(self):
  ps=self.selected_paths()
  if not ps:messagebox.showwarning("Atención","Seleccione uno o más POIs.");return
  z=export_pois(project_root()/"export",Path(self.turismo_root()),self.country_var.get(),self.province_var.get(),self.city_var.get(),ps);messagebox.showinfo("ZIP generado",f"Archivo creado:\n{z}");open_folder(project_root()/"export")
