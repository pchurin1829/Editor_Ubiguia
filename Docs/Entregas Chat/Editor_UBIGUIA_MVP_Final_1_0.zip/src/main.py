from ui_main import EditorUBIGUIA

def main():
    EditorUBIGUIA().mainloop()

if __name__=="__main__": main()
