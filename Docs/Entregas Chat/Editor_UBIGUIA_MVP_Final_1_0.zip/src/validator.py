from constants import *
def validate_poi(p):
 e=[]
 if not (p/POI_MASTER_FILE).exists():e.append("Falta POI_MASTER.md")
 if not (p/POI_JSON).exists():e.append("Falta poi.json")
 if not (p/SHARED_IMAGES_FOLDER).exists():e.append("Falta carpeta imagenes")
 for lang in LANGUAGES:
  ld=p/lang
  if not ld.exists():e.append(f"Falta carpeta {lang}");continue
  if not (ld/TEXT_FILE).exists():e.append(f"Falta {lang}/texto.md")
  if not (ld/META_FILE).exists():e.append(f"Falta {lang}/meta.json")
  if not (ld/AUDIO_FOLDER).exists():e.append(f"Falta {lang}/audio")
 return e
def validate_text(p):
 e=validate_poi(p)
 return "POI válido." if not e else "\n".join(e)
